import { motion, useReducedMotion } from 'framer-motion'
import eyeMark from './assets/eye-mark.png'
import { releases, artists } from './data/content'

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.05 },
  },
}

const item = {
  hidden: { opacity: 0, y: 18 },
  show: { opacity: 1, y: 0 },
}

function GlitchRule({ className = '' }) {
  return (
    <div className={`relative h-px w-full overflow-hidden ${className}`}>
      <div className="absolute inset-0 bg-white/10" />
      <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_0%,rgba(127,220,255,0.8)_50%,transparent_100%)] animate-pulse" />
    </div>
  )
}

function Pill({ children }) {
  return (
    <span className="inline-flex items-center rounded-full border border-white/15 bg-white/5 px-3 py-1 text-[11px] tracking-[0.22em] uppercase text-white/80 shadow-[0_0_0_1px_rgba(127,220,255,0.10)]">
      {children}
    </span>
  )
}

export default function App() {
  const reduce = useReducedMotion()

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Background */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(127,220,255,0.12),transparent_45%),radial-gradient(circle_at_80%_70%,rgba(127,220,255,0.10),transparent_50%)]" />

        {/* HUD grid */}
        <div className="absolute inset-0 opacity-[0.10] [background-image:linear-gradient(rgba(255,255,255,0.12)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.12)_1px,transparent_1px)] [background-size:48px_48px]" />

        {/* scanlines + grain */}
        <div className="absolute inset-0 scanlines grain" />

        {/* top glow bar */}
        <div className="absolute -top-32 left-1/2 h-64 w-[1100px] -translate-x-1/2 rounded-full bg-frost/10 blur-3xl" />
      </div>

      {/* Header */}
      <header className="relative z-10 mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-6 md:px-10">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-xl border border-white/10 bg-white/5 shadow-glow flex items-center justify-center">
            <div className="h-3 w-3 rounded-full bg-frost/60" />
          </div>
          <div>
            <div className="text-sm tracking-[0.34em] font-semibold">XTRAVAGANZA</div>
            <div className="text-[11px] tracking-[0.28em] uppercase text-white/60">RECORDINGS</div>
          </div>
        </div>

        <nav className="hidden items-center gap-8 text-[12px] tracking-[0.22em] uppercase text-white/70 md:flex">
          <a className="hover:text-white" href="#releases">Releases</a>
          <a className="hover:text-white" href="#artists">Artists</a>
          <a className="hover:text-white" href="#about">About</a>
          <a className="hover:text-white" href="#contact">Contact</a>
        </nav>

        <a
          href="#releases"
          className="jitter inline-flex items-center rounded-full border border-white/15 bg-white/5 px-4 py-2 text-[12px] tracking-[0.2em] uppercase text-white/80 shadow-glow hover:border-white/25 hover:bg-white/10"
        >
          View Releases
        </a>
      </header>

      {/* Hero */}
      <section className="relative z-10 mx-auto w-full max-w-6xl px-6 pb-16 pt-10 md:px-10 md:pb-24 md:pt-14">
        <motion.div variants={container} initial="hidden" animate="show" className="grid items-center gap-10 md:grid-cols-2 md:gap-12">
          <motion.div variants={item} className="order-2 md:order-1">
            <Pill>Future Sound</Pill>
            <h1 className="mt-6 text-4xl font-semibold tracking-tight md:text-6xl">
              Techy. Minimal.
              <span className="block text-white/70">Futuristic by design.</span>
            </h1>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-white/70 md:text-lg">
              XTRAVAGANZA Recordings is a forward-facing imprint for clean, high-definition club music —
              built around precision grooves, bold sound design, and a visual system that feels like a signal.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a
                href="#contact"
                className="inline-flex items-center rounded-full bg-frost/20 px-5 py-2.5 text-[12px] tracking-[0.22em] uppercase text-white shadow-glow hover:bg-frost/25"
              >
                Demo Submissions
              </a>
              <a
                href="#artists"
                className="inline-flex items-center rounded-full border border-white/15 bg-white/5 px-5 py-2.5 text-[12px] tracking-[0.22em] uppercase text-white/80 hover:border-white/25 hover:bg-white/10"
              >
                Meet the Artists
              </a>
            </div>

            <div className="mt-10">
              <GlitchRule className="opacity-70" />
              <div className="mt-4 flex flex-wrap gap-4 text-[11px] tracking-[0.22em] uppercase text-white/55">
                <span>Techno</span>
                <span>Minimal</span>
                <span>Glitch</span>
                <span>Future House</span>
              </div>
            </div>
          </motion.div>

          <motion.div variants={item} className="order-1 md:order-2">
            <div className="relative rounded-3xl border border-white/10 bg-white/5 p-6 shadow-glow">
              <div className="absolute inset-0 rounded-3xl bg-[radial-gradient(circle_at_50%_10%,rgba(127,220,255,0.20),transparent_50%)]" />
              <div className="relative">
                <div className="flex items-center justify-between">
                  <div className="text-[11px] tracking-[0.28em] uppercase text-white/55">Signal / Identity</div>
                  <div className="text-[11px] tracking-[0.28em] uppercase text-white/55">v1.0</div>
                </div>
                <GlitchRule className="mt-4" />

                <motion.div
                  aria-hidden
                  animate={reduce ? undefined : { y: [0, -6, 0] }}
                  transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
                  className="mt-8 flex items-center justify-center"
                >
                  <img
                    src={eyeMark}
                    alt="XTRAVAGANZA eye mark"
                    className="w-full max-w-[420px] opacity-95 drop-shadow-[0_0_26px_rgba(127,220,255,0.22)]"
                  />
                </motion.div>

                <div className="mt-8 text-center">
                  <div className="text-xl font-semibold tracking-[0.28em]">XTRAVAGANZA</div>
                  <div className="mt-2 text-[12px] tracking-[0.34em] uppercase text-white/65">Recordings</div>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* Releases */}
      <section id="releases" className="relative z-10 mx-auto w-full max-w-6xl px-6 py-16 md:px-10 md:py-20">
        <div className="flex items-end justify-between gap-6">
          <div>
            <Pill>Releases</Pill>
            <h2 className="mt-5 text-3xl font-semibold tracking-tight md:text-4xl">New & Featured</h2>
            <p className="mt-3 text-white/65">Placeholder catalog entries — swap in your real release data anytime.</p>
          </div>
          <a
            href="#"
            className="hidden rounded-full border border-white/15 bg-white/5 px-5 py-2 text-[12px] tracking-[0.22em] uppercase text-white/80 hover:border-white/25 hover:bg-white/10 md:inline-flex"
          >
            View All
          </a>
        </div>

        <GlitchRule className="mt-8" />

        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {releases.map((r, idx) => (
            <motion.div
              key={`${r.title}-${idx}`}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-20% 0px' }}
              transition={{ duration: 0.5, delay: idx * 0.05 }}
              className="group relative overflow-hidden rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glow"
            >
              <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(127,220,255,0.20),transparent_40%,rgba(255,255,255,0.06))] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              <div className="relative">
                <div className="flex items-center justify-between">
                  <div className="text-[11px] tracking-[0.28em] uppercase text-white/60">{r.year}</div>
                  <span className="rounded-full border border-white/15 bg-black/40 px-3 py-1 text-[11px] tracking-[0.22em] uppercase text-white/70">
                    {r.tag}
                  </span>
                </div>

                <div className="mt-4 aspect-square w-full rounded-2xl border border-white/10 bg-[radial-gradient(circle_at_30%_20%,rgba(127,220,255,0.18),transparent_45%),linear-gradient(180deg,rgba(255,255,255,0.06),rgba(0,0,0,0.0))]" />

                <div className="mt-5">
                  <div className="text-[12px] tracking-[0.26em] uppercase text-white/60">{r.artist}</div>
                  <div className="mt-2 text-lg font-semibold leading-snug">{r.title}</div>
                  <div className="mt-2 text-sm text-white/65">{r.subtitle}</div>
                </div>

                <div className="mt-5 flex items-center justify-between">
                  <div className="text-[11px] tracking-[0.22em] uppercase text-white/50">Stream / Buy</div>
                  <div className="h-8 w-8 rounded-full border border-white/15 bg-white/5 shadow-glow" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Artists */}
      <section id="artists" className="relative z-10 mx-auto w-full max-w-6xl px-6 py-16 md:px-10 md:py-20">
        <div>
          <Pill>Artists</Pill>
          <h2 className="mt-5 text-3xl font-semibold tracking-tight md:text-4xl">Roster</h2>
          <p className="mt-3 text-white/65">Real names can go here — imagery is placeholder for now.</p>
        </div>

        <GlitchRule className="mt-8" />

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {artists.map((name, idx) => (
            <motion.div
              key={`${name}-${idx}`}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-20% 0px' }}
              transition={{ duration: 0.5, delay: idx * 0.04 }}
              className="group relative overflow-hidden rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glow"
            >
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(127,220,255,0.18),transparent_50%)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              <div className="relative">
                <div className="aspect-[4/5] w-full rounded-2xl border border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.08),rgba(0,0,0,0.0)),radial-gradient(circle_at_70%_20%,rgba(127,220,255,0.14),transparent_50%)]" />
                <div className="mt-5 flex items-end justify-between">
                  <div>
                    <div className="text-[11px] tracking-[0.28em] uppercase text-white/55">Artist</div>
                    <div className="mt-2 text-lg font-semibold">{name}</div>
                  </div>
                  <div className="h-10 w-10 rounded-full border border-white/15 bg-black/40" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* About */}
      <section id="about" className="relative z-10 mx-auto w-full max-w-6xl px-6 py-16 md:px-10 md:py-20">
        <div className="grid gap-10 md:grid-cols-2 md:gap-12">
          <div>
            <Pill>About</Pill>
            <h2 className="mt-5 text-3xl font-semibold tracking-tight md:text-4xl">A signal-forward imprint</h2>
            <p className="mt-4 text-white/70 leading-relaxed">
              This layout is designed to match the futuristic reference style you approved: minimal typography, high-contrast
              surfaces, scanline texture, and a restrained icy accent.
            </p>
            <p className="mt-4 text-white/70 leading-relaxed">
              Swap in real artist photos, release artwork, and links — everything is wired to stay clean and consistent.
            </p>
          </div>
          <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-glow">
            <div className="text-[11px] tracking-[0.28em] uppercase text-white/55">Design Notes</div>
            <GlitchRule className="mt-4" />
            <ul className="mt-6 space-y-3 text-sm text-white/70">
              <li>• HUD grid + scanlines + grain (subtle)</li>
              <li>• Frost accent used sparingly for glow states</li>
              <li>• Framer Motion for smooth, modern motion</li>
              <li>• Single-page anchor navigation (GitHub Pages friendly)</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="relative z-10 mx-auto w-full max-w-6xl px-6 pb-24 pt-6 md:px-10">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-8 shadow-glow md:p-10">
          <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
            <div>
              <Pill>Contact</Pill>
              <h2 className="mt-5 text-3xl font-semibold tracking-tight md:text-4xl">Let’s build the roster</h2>
              <p className="mt-3 text-white/70">Replace these placeholders with your real submission + social links.</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <a
                href="mailto:demo@xtravaganzarecordings.com"
                className="inline-flex items-center rounded-full bg-frost/20 px-5 py-2.5 text-[12px] tracking-[0.22em] uppercase text-white shadow-glow hover:bg-frost/25"
              >
                Email
              </a>
              <a
                href="#"
                className="inline-flex items-center rounded-full border border-white/15 bg-white/5 px-5 py-2.5 text-[12px] tracking-[0.22em] uppercase text-white/80 hover:border-white/25 hover:bg-white/10"
              >
                Instagram
              </a>
              <a
                href="#"
                className="inline-flex items-center rounded-full border border-white/15 bg-white/5 px-5 py-2.5 text-[12px] tracking-[0.22em] uppercase text-white/80 hover:border-white/25 hover:bg-white/10"
              >
                SoundCloud
              </a>
            </div>
          </div>
        </div>

        <footer className="mt-10 flex flex-col items-start justify-between gap-4 border-t border-white/10 pt-8 text-[11px] tracking-[0.22em] uppercase text-white/50 md:flex-row md:items-center">
          <div>© {new Date().getFullYear()} XTRAVAGANZA Recordings</div>
          <div className="flex gap-6">
            <span className="text-white/40">Built for GitHub Pages</span>
            <span className="text-white/40">v1.0</span>
          </div>
        </footer>
      </section>
    </div>
  )
}
